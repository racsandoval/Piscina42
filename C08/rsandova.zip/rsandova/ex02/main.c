/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsandova <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/09 12:09:01 by rsandova          #+#    #+#             */
/*   Updated: 2019/12/09 12:13:01 by rsandova         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_abs.h"
#include <stdio.h>

int main()
{
	printf("VALUE %d\n", ABS(1));
	printf("VALUE %d\n", ABS(0));
	printf("VALUE %d\n", ABS(-1));
	printf("VALUE %d\n", ABS(-15));
	printf("VALUE %d\n", ABS(-13));
	printf("VALUE %d\n", ABS(-12312));
}
